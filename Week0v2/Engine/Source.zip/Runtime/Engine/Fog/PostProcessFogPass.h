#pragma once

#include "RenderPass.h"

class PostProcessFogPass : public RenderPass
{
public:
    void Init(ID3D11Device* device) override;
    void Render(ID3D11DeviceContext* context,
        ID3D11ShaderResourceView* sceneSRV,
        ID3D11ShaderResourceView* depthSRV,
        ID3D11RenderTargetView* outputRTV,
        const Vector3& cameraPos,
        float fogStart,
        float fogEnd,
        const Vector3& fogColor);

private:
    ComPtr<ID3D11PixelShader> m_fogShader;
    ComPtr<ID3D11SamplerState> m_sampler;
    ComPtr<ID3D11Buffer> m_cbFogParams;
};
