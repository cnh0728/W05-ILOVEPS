﻿#include "Engine.h"


UEngine::UEngine()
{
}

UEngine::~UEngine()
{
}

int32 UEngine::Init(HWND hwnd)
{
    return 0;
}

void UEngine::Tick(float deltaSceconds)
{
}
