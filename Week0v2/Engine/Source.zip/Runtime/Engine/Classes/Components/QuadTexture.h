#pragma once
#include "Define.h"

extern uint32 quadTextureInices[6];

extern FVertexTexture quadTextureVertices[4];